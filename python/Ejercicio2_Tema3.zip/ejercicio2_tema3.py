peso = float(input('Por favor ingrese su peso en kg: '))
altura = float(input('Por favor ingrese su altura en metros: '))

print(f'Tu índice de masa corporal es: {peso / altura ** 2:.2f} kg/m^2')
